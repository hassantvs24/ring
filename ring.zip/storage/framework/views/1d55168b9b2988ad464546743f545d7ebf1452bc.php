<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('public/fonts.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/global_assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/core.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/custom.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/printx.css')); ?>" rel="stylesheet" type="text/css">
</head>
<body onload="print()">
<div id="container">

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldContent('footer'); ?>

</div>
</body>
</html><?php /**PATH C:\wamp64\www\ring\resources\views/layouts/printx.blade.php ENDPATH**/ ?>