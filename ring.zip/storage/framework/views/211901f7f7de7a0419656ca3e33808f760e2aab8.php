<div class="form-group">
    <div class="checkbox">
        <label>
            <input name="<?php echo e($name ?? ''); ?>" class="<?php echo e($class ?? ''); ?>" value="<?php echo e($value ?? ''); ?>" type="checkbox"  <?php if(isset($required)): ?><span class="text-danger">*</span><?php endif; ?> <?php if(isset($checked)): ?> checked="checked"<?php endif; ?>>
            <?php echo e($label ?? ''); ?>

        </label>
    </div>
</div><?php /**PATH C:\wamp64\www\ring\resources\views/components/check.blade.php ENDPATH**/ ?>