<div class="panel panel-flat">
    <div class="panel-heading">
        <h6 class="panel-title"><i class="icon-<?php echo e($icon ?? 'cog3'); ?> position-left"></i> <?php echo e($name ?? 'Action Panel'); ?></h6>
    </div>
    <?php if(isset($action)): ?>
        <form action="<?php echo e($action); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
    <?php endif; ?>
    <div class="panel-body">
        <?php echo e($slot); ?>

    </div>
    <div class="panel-footer panel-footer-transparent">
        <div class="heading-elements">
            <button type="submit" class="btn bg-indigo-400 btn-xs heading-btn pull-right btn-labeled btn-labeled-left"><b><i class="icon-checkmark4"></i></b> Submit</button>
        </div>
    </div>
    <?php if(isset($action)): ?>
        </form>
    <?php endif; ?>
</div><?php /**PATH C:\wamp64\www\ring\resources\views/components/rpnl.blade.php ENDPATH**/ ?>