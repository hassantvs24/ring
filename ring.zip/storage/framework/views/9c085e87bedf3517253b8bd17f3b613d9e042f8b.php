<div class="form-group <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <?php
        $set_id = $id ??  mt_rand();
    ?>
    <label for="<?php echo e($set_id); ?>" class="control-label col-lg-3"><?php echo e($label ?? ''); ?> <?php if($required == 'required'): ?><span class="text-danger">*</span><?php endif; ?></label>
    <div class="col-lg-9">
        <select id="<?php echo e($set_id); ?>" name="<?php echo e($name ?? ''); ?>" class="form-control <?php echo e($class ?? ''); ?>"  <?php echo e($rest ?? ''); ?> <?php if($required == 'required'): ?> required <?php endif; ?> >
            <?php echo e($slot); ?>

        </select>

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
</div><?php /**PATH C:\wamp64\www\ring\resources\views\components\select.blade.php ENDPATH**/ ?>