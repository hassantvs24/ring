


<?php $__env->startSection('title'); ?>
    User List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Site::class, ['name' => 'User List']); ?>
<?php $component->withName('site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['body' => 'Add New User']); ?>

         <?php $__env->slot('header'); ?> 
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User Create')): ?>
                <button id="headerBtn" type="button" class="btn btn-primary heading-btn btn-labeled btn-labeled-left" data-toggle="modal" data-target="#myModal"><b><i class="icon-add-to-list"></i></b> Add New User</button>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">Name</th>
                <th class="p-th">Email</th>
                <th class="p-th">User Roles</th>
                <th class="p-th">Default Warehouse</th>
                <th class="p-th">Default Account Book</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $role = $row->getRoleNames()->first();
                    if($role != null){
                        $role_id = $row->roles()->first()->id;
                    }

                ?>
                <tr>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->email); ?></td>
                    <td class="p-td"><?php echo e($role ?? ''); ?></td>
                    <td class="p-td"><?php echo e($row->warehouse['name']); ?></td>
                    <td class="p-td"><?php echo e($row->accountBook['name']); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User Edit')): ?>
                                <li><a href="<?php echo e(route('users.update', ['user' => $row->id])); ?>"
                                   data-role="<?php echo e($role_id ?? ''); ?>"
                                   data-name="<?php echo e($row->name); ?>"
                                   data-email="<?php echo e($row->email); ?>"
                                   data-warehouses="<?php echo e($row->warehouses_id); ?>"
                                   data-accounts="<?php echo e($row->account_books_id); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User Delete')): ?>
                                <li><a href="<?php echo e(route('users.destroy', ['user' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                            <?php endif; ?>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266)): ?>
<?php $component = $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266; ?>
<?php unset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var name = $(this).data('name');
                var email = $(this).data('email');
                var warehouses_id = $(this).data('warehouses');
                var account_books_id = $(this).data('accounts');
                var role_id = $(this).data('role');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=email]').val(email);
                $('#ediModal [name=warehouses_id]').val(warehouses_id).select2();
                $('#ediModal [name=account_books_id]').val(account_books_id).select2();
                $('#ediModal [name=role_id]').val(role_id).select2();
            });

            $('.warehouses, .accounts, .roles').select2();

            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [4] }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.box.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/users/users.blade.php ENDPATH**/ ?>