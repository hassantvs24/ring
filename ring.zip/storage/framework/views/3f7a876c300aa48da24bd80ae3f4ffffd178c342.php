<!-- Main sidebar -->
<div class="sidebar sidebar-main sidebar-fixed">
    <div class="sidebar-content">
        <!-- Main navigation -->
        <div class="sidebar-category sidebar-category-visible">
            <div class="category-content no-padding">
                <ul class="navigation navigation-main navigation-accordion">

                    <!-- Main -->

                    <li class="<?php echo e(Route::currentRouteName() == 'index' ? 'active':''); ?>"><a href="<?php echo e(route('index')); ?>"><i class="icon-home4"></i> <span>Dashboard</span></a></li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Sales Create', 'Sales List', 'Quotations List', 'Draft List'])): ?>
                        <li class="navigation-divider"></li>
                            <li class=""><a href="#"><i class=" icon-cart5"></i> <span>Sales</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sales Create')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'sales.index' ? 'active':''); ?>"><a href="<?php echo e(route('sales.index')); ?>"><i class="icon-diamond"></i> Add Sales</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sales List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'sales-list.index' ? 'active':''); ?>"><a href="<?php echo e(route('sales-list.index')); ?>"><i class="icon-diamond"></i> Invoice List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Quotations List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'sales.quotation' ? 'active':''); ?>"><a href="<?php echo e(route('sales.quotation')); ?>"><i class="icon-diamond"></i> Quotations List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Draft List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'sales.draft' ? 'active':''); ?>"><a href="<?php echo e(route('sales.draft')); ?>"><i class="icon-diamond"></i> Draft List</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Customer List', 'Customer Category List', 'Agent List', 'District List', 'SubDistrict List'])): ?>
                        <li class=""><a href="#"><i class=" icon-users4"></i> <span>Customers</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Customer List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'customer.index' ? 'active':''); ?>"><a href="<?php echo e(route('customer.index')); ?>"><i class="icon-diamond"></i> Customers List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Customer Category List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'customer-category.index' ? 'active':''); ?>"><a href="<?php echo e(route('customer-category.index')); ?>"><i class="icon-diamond"></i> Customers Category</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Agent List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'agent.index' ? 'active':''); ?>"><a href="<?php echo e(route('agent.index')); ?>"><i class="icon-diamond"></i> Agent List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('District List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'district.index' ? 'active':''); ?>"><a href="<?php echo e(route('district.index')); ?>"><i class="icon-diamond"></i> District</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('SubDistrict List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'sub-district.index' ? 'active':''); ?>"><a href="<?php echo e(route('sub-district.index')); ?>"><i class="icon-diamond"></i> Sub-district</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Product List', 'Product Category List', 'Product Units List', 'Product Brand List', 'Product Company List', 'Stock Adjustment List'])): ?>
                        <li class="navigation-divider"></li>

                        <li class=""><a href="#"><i class=" icon-truck"></i> <span>Stock</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'products.index' ? 'active':''); ?>"><a href="<?php echo e(route('products.index')); ?>"><i class="icon-diamond"></i> Product List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product Category List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'product-category.index' ? 'active':''); ?>"><a href="<?php echo e(route('product-category.index')); ?>"><i class="icon-diamond"></i> Product Category</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product Units List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'units.index' ? 'active':''); ?>"><a href="<?php echo e(route('units.index')); ?>"><i class="icon-diamond"></i> Units</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product Brand List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'brand.index' ? 'active':''); ?>"><a href="<?php echo e(route('brand.index')); ?>"><i class="icon-diamond"></i> Brands</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product Company List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'company.index' ? 'active':''); ?>"><a href="<?php echo e(route('company.index')); ?>"><i class="icon-diamond"></i> Company</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Stock Adjustment List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'adjustment.index' ? 'active':''); ?>"><a href="<?php echo e(route('adjustment.index')); ?>"><i class="icon-diamond"></i> Stock Adjustment</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Purchase Create', 'Purchase List', 'Pending List', 'Order List'])): ?>
                        <li class="navigation-divider"></li>

                        <li class=""><a href="#"><i class=" icon-cart"></i> <span>Purchase</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Purchase Create')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'purchase.index' ? 'active':''); ?>"><a href="<?php echo e(route('purchase.index')); ?>"><i class="icon-diamond"></i> Add Purchase</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Purchase List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'purchase-list.index' ? 'active':''); ?>"><a href="<?php echo e(route('purchase-list.index')); ?>"><i class="icon-diamond"></i> Purchase List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Pending List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'purchase.pending' ? 'active':''); ?>"><a href="<?php echo e(route('purchase.pending')); ?>"><i class="icon-diamond"></i> Pending List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Order List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'purchase.ordered' ? 'active':''); ?>"><a href="<?php echo e(route('purchase.ordered')); ?>"><i class="icon-diamond"></i> Ordered List</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Supplier List', 'Supplier Category List'])): ?>
                        <li class=""><a href="#"><i class=" icon-user-plus"></i> <span>Suppliers</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'supplier.index' ? 'active':''); ?>"><a href="<?php echo e(route('supplier.index')); ?>"><i class="icon-diamond"></i> Suppliers List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Category List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'supplier-category.index' ? 'active':''); ?>"><a href="<?php echo e(route('supplier-category.index')); ?>"><i class="icon-diamond"></i> Suppliers Category</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Expense List', 'Expense Category List'])): ?>
                        <li class="navigation-divider"></li>

                        <li class=""><a href="#"><i class=" icon-box-remove"></i> <span>Expenses</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Expense List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'expenses.index' ? 'active':''); ?>"><a href="<?php echo e(route('expenses.index')); ?>"><i class="icon-diamond"></i> All Expenses</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Expense Category List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'expense-category.index' ? 'active':''); ?>"><a href="<?php echo e(route('expense-category.index')); ?>"><i class="icon-diamond"></i> Expense Category</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Accounts List', 'Cash Flow View', 'Trial Balance View', 'Balance Sheet View'])): ?>
                        <li class=""><a href="#"><i class=" icon-calculator3"></i> <span>Payment Account</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Accounts List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'accounts.index' ? 'active':''); ?>"><a href="<?php echo e(route('accounts.index')); ?>"><i class="icon-diamond"></i> Accounts List</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Balance Sheet View')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'accounts.balance' ? 'active':''); ?>"><a href="<?php echo e(route('accounts.balance')); ?>"><i class="icon-diamond"></i> Balance Sheet</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Trial Balance View')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'accounts.trial' ? 'active':''); ?>"><a href="<?php echo e(route('accounts.trial')); ?>"><i class="icon-diamond"></i> Trial Balance</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cash Flow View')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'accounts.cash' ? 'active':''); ?>"><a href="<?php echo e(route('accounts.cash')); ?>"><i class="icon-diamond"></i> Cash Flow</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['User List', 'Role List'])): ?>
                        <li class=""><a href="#"><i class=" icon-users"></i> <span>Users</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('User List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'users.index' ? 'active':''); ?>"><a href="<?php echo e(route('users.index')); ?>"><i class="icon-diamond"></i> All Users</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Role List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'roles.index' ? 'active':''); ?>"><a href="<?php echo e(route('roles.index')); ?>"><i class="icon-diamond"></i> User Roles</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Business Setup', 'Warehouse List', 'Discount List', 'Vat List', 'Shipment List', 'Zone List'])): ?>
                        <li class=""><a href="#"><i class=" icon-hammer-wrench"></i> <span>Settings</span></a>
                            <ul>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Business Setup')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'business.show' ? 'active':''); ?>"><a href="<?php echo e(route('business.show', ['business' => Auth::user()->business_id])); ?>"><i class="icon-diamond"></i> Business Setup</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Warehouse List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'warehouse.index' ? 'active':''); ?>"><a href="<?php echo e(route('warehouse.index')); ?>"><i class="icon-diamond"></i> Warehouse</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Discount List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'discount.index' ? 'active':''); ?>"><a href="<?php echo e(route('discount.index')); ?>"><i class="icon-diamond"></i> Discount</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Vat List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'vat-tax.index' ? 'active':''); ?>"><a href="<?php echo e(route('vat-tax.index')); ?>"><i class="icon-diamond"></i> Vat Tax</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Shipment List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'shipment.index' ? 'active':''); ?>"><a href="<?php echo e(route('shipment.index')); ?>"><i class="icon-diamond"></i> Shipment</a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Zone List')): ?>
                                    <li class="<?php echo e(Route::currentRouteName() == 'zone.index' ? 'active':''); ?>"><a href="<?php echo e(route('zone.index')); ?>"><i class="icon-diamond"></i> Zone</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Reports Generate')): ?>
                        <li class=""><a href="#"><i class=" icon-chart"></i> <span>Reports</span></a>
                            <ul>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.profit-loss' ? 'active':''); ?>"><a href="<?php echo e(route('reports.profit-loss')); ?>"><i class="icon-diamond"></i> Profit/Loss Reports</a></li>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.expense' ? 'active':''); ?>"><a href="<?php echo e(route('reports.expense')); ?>"><i class="icon-diamond"></i> Expense Reports</a></li>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.sales' ? 'active':''); ?>"><a href="<?php echo e(route('reports.sales')); ?>"><i class="icon-diamond"></i> Sales Reports</a></li>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.purchase' ? 'active':''); ?>"><a href="<?php echo e(route('reports.purchase')); ?>"><i class="icon-diamond"></i> Purchase Reports</a></li>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.stock' ? 'active':''); ?>"><a href="<?php echo e(route('reports.stock')); ?>"><i class="icon-diamond"></i> Stock Reports</a></li>
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.customer' ? 'active':''); ?>"><a href="<?php echo e(route('reports.customer')); ?>"><i class="icon-diamond"></i> Customer Reports</a></li>
                                <!--<li class="<?php echo e(Route::currentRouteName() == 'reports.supplier' ? 'active':''); ?>"><a href="<?php echo e(route('reports.supplier')); ?>"><i class="icon-diamond"></i> Supplier Reports</a></li>-->
                                <li class="<?php echo e(Route::currentRouteName() == 'reports.accounts' ? 'active':''); ?>"><a href="<?php echo e(route('reports.accounts')); ?>"><i class="icon-diamond"></i> Accounts Reports</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <li class="navigation-divider"></li>

                </ul>
            </div>
        </div>
        <!-- /main navigation -->
    </div>
</div>
<!-- /main sidebar --><?php /**PATH C:\wamp64\www\ring\resources\views/shared/aside.blade.php ENDPATH**/ ?>