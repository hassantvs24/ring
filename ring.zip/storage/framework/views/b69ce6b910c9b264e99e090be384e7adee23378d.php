<div class="input-group mb-15">
    <?php if(isset($label)): ?>
        <span class="input-group-addon"><?php echo e($label); ?></span>
    <?php endif; ?>
        <select id="<?php echo e($id ?? ''); ?>" name="<?php echo e($name ?? ''); ?>" class="form-control <?php echo e($class ?? ''); ?>"  <?php echo e($rest ?? ''); ?> <?php if($required == 'required'): ?> required <?php endif; ?> >
            <?php echo e($slot); ?>

        </select>
    <?php if(isset($btn)): ?>
        <span class="input-group-btn">
            <?php echo e($btn); ?>

        </span>
    <?php endif; ?>
</div>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="help-block"><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH C:\wamp64\www\ring\resources\views/components/dselect.blade.php ENDPATH**/ ?>