


<?php $__env->startSection('title'); ?>
    Accounts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Site::class, ['name' => 'Accounts']); ?>
<?php $component->withName('site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['body' => 'Add New Account']); ?>

         <?php $__env->slot('header'); ?> 
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Accounts Create')): ?>
                <button id="headerBtn" type="button" class="btn btn-primary heading-btn btn-labeled btn-labeled-left" data-toggle="modal" data-target="#myModal"><b><i class="icon-add-to-list"></i></b> Add New Account</button>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">Name</th>
                <th class="p-th">Account Number</th>
                <th class="p-th">Descriptions</th>
                <th class="p-th">IN</th>
                <th class="p-th">OUT</th>
                <th class="p-th">Balance</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->account_number); ?></td>
                    <td class="p-td"><?php echo e($row->description); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->in())); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->out())); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->acBalance())); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Accounts Edit')): ?>
                                <li><a href="<?php echo e(route('accounts.update', ['list' => $row->id])); ?>"
                                   data-name="<?php echo e($row->name); ?>"
                                   data-acnumber="<?php echo e($row->account_number); ?>"
                                   data-description="<?php echo e($row->description); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Accounts Transaction')): ?>
                                <li><a href="<?php echo e(route('accounts.show', ['list' => $row->id])); ?>"><i class="icon-shuffle text-primary"></i> Account Transaction</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Transaction Create')): ?>
                                <li><a href="<?php echo e(route('accounts.payment', ['id' => $row->id])); ?>" class="payments" data-toggle="modal" data-target="#acModal"><i class="icon-wallet text-purple"></i> Make Transaction</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Accounts Delete')): ?>
                                <li><a href="<?php echo e(route('accounts.destroy', ['list' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                            <?php endif; ?>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266)): ?>
<?php $component = $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266; ?>
<?php unset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

        $(function () {
            $('.warehouse').val("<?php echo e(auth()->user()->warehouses_id); ?>").select2();

            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var name = $(this).data('name');
                var account_number = $(this).data('acnumber');
                var description = $(this).data('description');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=account_number]').val(account_number);
                $('#ediModal [name=description]').val(description);
            });

            $('.payments').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');

                $('#acModal form').attr('action', url);

                $('#acModal [name=amount]').val(0);

                $('.cheque_number').hide();
                $('.bank_account_no').hide();
                $('.transaction_no').hide();
            });

            $('.payment_method, .transaction_type').select2();

            $('.payment_method').change(function () {
                var methods = $(this).val();
                switch(methods) {
                    case "Cheque":
                        $('.cheque_number').show();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        break;
                    case "Bank Transfer":
                        $('.cheque_number').hide();
                        $('.bank_account_no').show();
                        $('.transaction_no').hide();
                        break;
                    case "Other":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').show();
                        break;
                    case "Customer Account":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        break;
                    default:
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                }
            });

            $('.date_pic').daterangepicker({
                singleDatePicker: true,
                locale: {
                    format: 'DD/MM/YYYY'
                }
            });


            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [6] }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('accounts.box.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/accounts/account.blade.php ENDPATH**/ ?>