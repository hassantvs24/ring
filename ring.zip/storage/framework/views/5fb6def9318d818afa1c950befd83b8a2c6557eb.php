

<?php $__env->startSection('title'); ?>
    Product Stock Reports
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.print','data' => ['header' => 'Product Stock Reports']]); ?>
<?php $component->withName('print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => 'Product Stock Reports']); ?>

        <?php if(!empty($request['stock_lower'])): ?>
            <?php if($request['stock_lower'] == 'limit'): ?>{
                <?php
                    $tablex = $table->where('StockLower',1)->all();
                ?>

            <?php $__env->slot('sub'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report']); ?>Lowe Stock Report <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>
            <?php else: ?>
                <?php
                    $tablex = $table->where('CurrentStock', '<=', 0)->all();
                ?>

                  <?php $__env->slot('sub'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report']); ?>Out of Stock Report <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

            <?php endif; ?>
        <?php else: ?>
            <?php
                $tablex = $table;
            ?>

        <?php endif; ?>

         <?php $__env->slot('subr'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report Date']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report Date']); ?><?php echo e(date('d/m/Y')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

        <table class="table table-condensed table-bordered table-striped">
            <thead>
            <tr>
                <th>S/N</th>
                <th>Name</th>
                <th>Type</th>
                <th>Category</th>
                <th>Company</th>
                <th>Sales Price</th>
                <th>Purchase Price</th>
                <th>Stock</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $sales = 0;
                $purchase = 0;
            ?>
            <?php $__currentLoopData = $tablex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->sku); ?></td>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->product_type); ?></td>
                    <td class="p-td"><?php echo e($row->productCategory['name']); ?></td>
                    <td class="p-td"><?php echo e($row->company['name']); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->sell_price)); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->purchase_price)); ?></td>
                    <td class="p-td"><?php echo e($row->currentStock()); ?> <?php echo e($row->unit['name']); ?></td>
                </tr>
                <?php
                    $sales += ($row->currentStock() * $row->sell_price);
                    $purchase += ($row->currentStock() * $row->purchase_price);
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <th></th>
                <th>
                    <p class="m-0"><b>Total Sales Value</b></p>
                    <?php echo e(money_c($sales)); ?>

                </th>
                <th></th>
                <th></th>
                <th>
                    <p class="m-0"><b>Total Purchase Value</b></p>
                    <?php echo e(money_c($purchase)); ?>

                </th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            </tfoot>
        </table>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/reports/print/stock-product.blade.php ENDPATH**/ ?>