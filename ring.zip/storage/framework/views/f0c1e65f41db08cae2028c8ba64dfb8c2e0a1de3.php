<?php $__env->startSection('content'); ?>

    <!-- Advanced login -->
    <form  method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="panel panel-body login-form">
            <div class="text-center">
                <div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
                <h5 class="content-group">Login to your account <small class="display-block">Your credentials</small></h5>
            </div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                <div class="form-control-feedback">
                    <i class="icon-envelop text-muted"></i>
                </div>
                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <input type="password" class="form-control" placeholder="Password" name="password" required>
                <div class="form-control-feedback">
                    <i class="icon-lock2 text-muted"></i>
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group login-options">
                <div class="row">
                    <div class="col-sm-6">
                        <label class="checkbox-inline">
                            <input type="checkbox" class="styled" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            Remember
                        </label>
                    </div>

                    <div class="col-sm-6 text-right">
                        <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <button type="submit" class="btn bg-blue btn-block">Login <i class="icon-arrow-right14 position-right"></i></button>
            </div>

            <div class="content-divider text-muted form-group"><span>Don't have an account?</span></div>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-default btn-block content-group">Sign up</a>
        </div>
    </form>
    <!-- /advanced login -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\auth\login.blade.php ENDPATH**/ ?>