<div class="panel panel-default">
    <?php if(isset($name)): ?>
        <div class="panel-heading">
            <h5 class="panel-title"><i class="icon-shutter text-info"></i> <?php echo e($name ?? ''); ?></h5>
            <?php if(isset($header)): ?>
                <div class="heading-elements">
                    <?php echo e($header); ?>

                </div>
            <?php endif; ?>

        </div>

    <?php endif; ?>

    <div class="panel-body"></div>

    <div class="table-responsive" style="overflow-x: inherit;">
        <?php echo e($slot); ?>

    </div>

</div>
<?php /**PATH C:\wamp64\www\ring\resources\views\components\site.blade.php ENDPATH**/ ?>