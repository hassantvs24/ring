


<?php $__env->startSection('title'); ?>
    Customer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Page::class, ['name' => 'Customer List','body' => 'Add New Customer']); ?>
<?php $component->withName('page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">S/N</th>
                <th class="p-th">Name</th>
                <th class="p-th">Contact</th>
                <th class="p-th">Address</th>
                <th class="p-th">Zone</th>
                <th class="p-th">Category</th>
                <th title="Credit Limit" class="p-th">Cr.Limit</th>
                <th class="p-th" title="Monthly Target">Target</th>
                <th class="p-th">Balance</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->code); ?></td>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->contact); ?></td>
                    <td class="p-td"><?php echo e($row->address); ?></td>
                    <td class="p-td"><?php echo e($row->zone['name']); ?></td>
                    <td class="p-td"><?php echo e($row->customerCategory['name']); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->credit_limit)); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->sells_target)); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->dueBalance())); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <li><a href="<?php echo e(route('customer.update', ['list' => $row->id])); ?>"
                                   data-code="<?php echo e($row->code); ?>"
                                   data-name="<?php echo e($row->name); ?>"
                                   data-contact="<?php echo e($row->contact); ?>"
                                   data-email="<?php echo e($row->email); ?>"
                                   data-address="<?php echo e($row->address); ?>"
                                   data-phone="<?php echo e($row->phone); ?>"
                                   data-contacttwo="<?php echo e($row->alternate_contact); ?>"
                                   data-zone="<?php echo e($row->zones_id); ?>"
                                   data-category="<?php echo e($row->customer_categories_id); ?>"
                                   data-warehouse="<?php echo e($row->warehouses_id); ?>"
                                   data-crlimit="<?php echo e($row->credit_limit); ?>"
                                   data-starget="<?php echo e($row->sells_target); ?>"
                                   data-balance="<?php echo e($row->balance); ?>"
                                   data-description="<?php echo e($row->description); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                            <li><a href="<?php echo e(route('customer.transaction', ['id' => $row->id])); ?>"><i class="icon-shuffle text-primary"></i> Customer Transaction</a></li>
                            <li><a href="<?php echo e(route('customer.payment', ['id' => $row->id])); ?>" class="payment" data-balance="<?php echo e($row->dueBalance()); ?>" data-toggle="modal" data-target="#payModal"><i class="icon-wallet text-purple"></i> Payment</a></li>
                            <li><a href="<?php echo e(route('customer.destroy', ['list' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89)): ?>
<?php $component = $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89; ?>
<?php unset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        var balance = 0;
        $(function () {

            $('.warehouse').val("<?php echo e(auth()->user()->warehouses_id); ?>").select2();
            $('.accounts').val("<?php echo e(auth()->user()->account_books_id); ?>").select2();

            $('.category, .zone, .payment_method').select2();

            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var name = $(this).data('name');
                var code = $(this).data('code');
                var email = $(this).data('email');
                var address = $(this).data('address');
                var phone = $(this).data('phone');
                var alternate_contact = $(this).data('contacttwo');
                var zones_id = $(this).data('zone');
                var contact = $(this).data('contact');
                var warehouses_id = $(this).data('warehouse');
                var credit_limit = $(this).data('crlimit');
                var sells_target = $(this).data('starget');
                var balance = $(this).data('balance');
                var customer_categories_id = $(this).data('category');
                var description = $(this).data('description');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=code]').val(code);
                $('#ediModal [name=email]').val(email);
                $('#ediModal [name=address]').val(address);
                $('#ediModal [name=phone]').val(phone);
                $('#ediModal [name=alternate_contact]').val(alternate_contact);
                $('#ediModal [name=contact]').val(contact);
                $('#ediModal [name=credit_limit]').val(credit_limit);
                $('#ediModal [name=sells_target]').val(sells_target);
                $('#ediModal [name=balance]').val(balance);
                $('#ediModal [name=description]').val(description);

                $('#ediModal [name=zones_id]').val(zones_id).select2();
                $('#ediModal [name=warehouses_id]').val(warehouses_id).select2();
                $('#ediModal [name=customer_categories_id]').val(customer_categories_id).select2();

            });

            $('.payment').click(function (e) {
                e.preventDefault();

                $('#payModal [name=amount]').val(0);

                $('.cheque_number').hide();
                $('.bank_account_no').hide();
                $('.transaction_no').hide();
                $('.customer_balance').hide();

                var url = $(this).attr('href');
                balance = Number($(this).data('balance'));

                /*$('#payModal [name=amount]').dblclick(function () {
                    $(this).val(balance);
                    disible_submit();
                });*/

                $('#payModal form').attr('action', url);
                disible_submit();
            });


            $('.payment_method').change(function () {
                var methods = $(this).val();
                switch(methods) {
                    case "Cheque":
                        $('.cheque_number').show();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                        break;
                    case "Bank Transfer":
                        $('.cheque_number').hide();
                        $('.bank_account_no').show();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                        break;
                    case "Other":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').show();
                        $('.customer_balance').hide();
                        break;
                    case "Customer Account":
                        $('.customer_balance').html('Account Current Balance: '+parseFloat(balance).toFixed(2));
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').show();
                        break;
                    default:
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                }

                disible_submit();

            });

            $('#payModal [name=amount]').on('keyup keydown change', function () {
                disible_submit();
            });

            $('.date_pic').daterangepicker({
                singleDatePicker: true,
                locale: {
                    format: 'DD/MM/YYYY'
                }
            });


            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [9] }
                ]
            });
        });
        
        function disible_submit() {
            var amount = $('#payModal [name=amount]').val();
            var payment_method = $('.payment_method').val();

            if(amount <= 0 || amount > balance && payment_method == 'Customer Account'){
                $('#payModal [type=submit]').prop('disabled', true);
            }else{
                $('#payModal [type=submit]').prop('disabled', false);
            }
        }
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.box.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\customer\customer.blade.php ENDPATH**/ ?>