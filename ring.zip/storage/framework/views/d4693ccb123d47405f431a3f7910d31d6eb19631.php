<div id="<?php echo e($id); ?>" class="modal fade">
    <div class="modal-dialog <?php echo e($size); ?>">
        <div class="modal-content">
            <?php if(isset($title)): ?>
            <div class="modal-header bg-<?php echo e($bg); ?>">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h5 class="modal-title"><i class="icon-<?php echo e($icon); ?>"></i> <?php echo e($title); ?></h5>
            </div>
            <?php endif; ?>
            <?php if(isset($action)): ?>
            <form action="<?php echo e($action); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <?php endif; ?>
                <div class="modal-body">
                    <?php echo e($slot); ?>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-labeled btn-labeled-left" data-dismiss="modal"><b><i class="icon-cancel-circle2"></i></b> Close</button>
                    <button type="submit" class="btn btn-<?php echo e($bg); ?> btn-labeled btn-labeled-left"><b><i class="icon-checkmark4"></i></b> Save changes</button>
                </div>
            <?php if(isset($action)): ?>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\ring\resources\views\components\modal.blade.php ENDPATH**/ ?>