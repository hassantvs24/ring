<div class="input-group mb-15">
    <?php if(isset($addon)): ?>
        <span class="input-group-addon"><?php echo e($addon); ?></span>
    <?php endif; ?>
    <input id="<?php echo e($id ?? ''); ?>" name="<?php echo e($name ?? ''); ?>" type="<?php echo e($type ?? 'text'); ?>" class="form-control <?php echo e($class ?? ''); ?>"  placeholder="<?php echo e($label ?? ''); ?>" value="<?php echo e($value ?? ''); ?>" <?php echo e($rest ?? ''); ?> <?php if($required == 'required'): ?> required <?php endif; ?> />
    <?php if(isset($btn)): ?>
        <span class="input-group-btn">
            <?php echo e($btn); ?>

        </span>
    <?php endif; ?>
</div>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="help-block"><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH C:\wamp64\www\ring\resources\views/components/dinput.blade.php ENDPATH**/ ?>