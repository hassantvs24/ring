

<?php $__env->startSection('title'); ?>
    Sales Invoice
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
     <?php if (isset($component)) { $__componentOriginal47312de6fbe263368632b8bfeae694afaf43bbcf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Signature::class, ['left' => 'Authorize Signature','right' => 'Customer Signature']); ?>
<?php $component->withName('signature'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal47312de6fbe263368632b8bfeae694afaf43bbcf)): ?>
<?php $component = $__componentOriginal47312de6fbe263368632b8bfeae694afaf43bbcf; ?>
<?php unset($__componentOriginal47312de6fbe263368632b8bfeae694afaf43bbcf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal73379b5afe2d342764d35ec8392c37afa2fb25ad = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PrintFooter::class, []); ?>
<?php $component->withName('print-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Infinity Flame Soft Rongmohol Tower, Bondor Bazar 3100 Sylhet Tel: +880 1675 870047 Email: contact@website.com Web: www.website.com <?php if (isset($__componentOriginal73379b5afe2d342764d35ec8392c37afa2fb25ad)): ?>
<?php $component = $__componentOriginal73379b5afe2d342764d35ec8392c37afa2fb25ad; ?>
<?php unset($__componentOriginal73379b5afe2d342764d35ec8392c37afa2fb25ad); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="header">
        <div id="logo">
            <img src="<?php echo e(asset('public/')); ?>/logo_<?php echo e($table->warehouse->getRawOriginal('logo') ?? $table->business->getRawOriginal('logo')); ?>" alt="Logo">
        </div>
        <div id="reference">
            <h3><strong>Invoice</strong></h3>
            <h4>S/N : <?php echo e($table->code); ?></h4>
            <p>Date : <?php echo e(pub_date($table->created_at)); ?></p>
        </div>
    </div>

    <div id="fromto">
        <div id="from">
            <p>
                <strong><?php echo e($table->warehouse['name'] ?? $table->business['name']); ?></strong><br />
                <?php echo e($table->warehouse['address'] ?? $table->business['address']); ?><br />
                Cell: <?php echo e($table->warehouse['contact'] ?? $table->business['contact']); ?> <br />
                Email: <?php echo e($table->warehouse['email'] ?? $table->business['email']); ?> <br />
                Web: <?php echo e($table->warehouse['website'] ?? $table->business['website']); ?>

            </p>
        </div>
        <div id="to">
            <p>
                <strong><?php echo e($table->name); ?></strong><br />
                <?php echo e($table->address); ?><br />
                Cell: <?php echo e($table->contact); ?><br />
                Customer ID: <?php echo e($table->code); ?>

                <hr />
                <p><strong>Invoice Due: <?php echo e(money_c($table->invoice_due())); ?></strong></p>
                <p><strong>Total Due: <?php echo e(money_c($table->customer->dueBalancex() ?? 0)); ?></strong></p>

            </p>
        </div>
    </div>

    <div id="items">
        <table>
            <tr>
                <th>Description</th>
                <th>Rate</th>
                <th>Qty</th>
                <th>Total</th>
            </tr>
            <?php
                $items = $table->invoiceItems()->get();
            ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e(money_c($row->amount)); ?></td>
                    <td><?php echo e($row->quantity); ?> <?php echo e($row->unit); ?></td>
                    <td><?php echo e(money_c($row->amount * $row->quantity)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tfoot>
            <tr>
                <th colspan="3" style="text-align: right;">Total </th>
                <th><?php echo e(money_c($table->invoice_total())); ?></th>
            </tr>
            </tfoot>
        </table>
        <p><b>In word: </b><?php echo e(in_word($table->invoice_sub_total())); ?></p>
    </div>

    <div id="summary">
        <div id="note">
            <h4>Note :</h4>
            <p><?php echo e($table->description); ?></p>
        </div>
        <div id="total">
            <table border="1">
                <tr>
                    <td>Discount</td>
                    <td><?php echo e(money_c($table->discount_amount)); ?></td>
                </tr>
                <tr>
                    <td>Total VAT</td>
                    <td><?php echo e(money_c($table->vet_texes_amount)); ?></td>
                </tr>
                <tr>
                    <td>Other Cost</td>
                    <td><?php echo e(money_c($table->additional_charges)); ?></td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td><?php echo e(money_c($table->invoice_sub_total())); ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/sales/print/invoice.blade.php ENDPATH**/ ?>