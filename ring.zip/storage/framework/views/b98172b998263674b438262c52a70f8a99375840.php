


<?php $__env->startSection('title'); ?>
    Balance Sheet
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Panel::class, ['name' => 'Balance Sheet']); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-bordered table-condensed table-hover">
            <thead>
            <tr>
                <th>Liability</th>
                <th>Assets</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="vertical-align: top;">
                        <p><b>Supplier Due:</b> <?php echo e(money_c($supplier_due)); ?></p>
                    </td>
                    <td style="vertical-align: top;">
                        <p><b>Customer Due:</b> <?php echo e(money_c($customer_due)); ?></p>
                        <p><b>Closing Stock:</b> <?php echo e(money_c($stock_value)); ?></p>
                        <p><b>Account Balance:</b> <br />
                            <?php
                                $ac_balance = 0;
                            ?>
                            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="pl-20"><?php echo e($row->name); ?>: <?php echo e(money_c($row->acBalance())); ?></p>
                                <?php
                                    $ac_balance += $row->acBalance();
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th><b>Total Liability:	</b> <?php echo e(money_c($total_liability)); ?></th>
                    <th><b>Total Assets: </b> <?php echo e(money_c($total_asset + $ac_balance)); ?></th>
                </tr>
            </tfoot>
        </table>

     <?php if (isset($__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52)): ?>
<?php $component = $__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52; ?>
<?php unset($__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('box.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/accounts/balance_sheet.blade.php ENDPATH**/ ?>