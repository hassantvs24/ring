<div class="panel panel-flat <?php echo e($class ?? ''); ?>">
    <?php if(isset($name)): ?>
        <div class="panel-heading">
            <h5 class="panel-title"><?php echo e($name ?? ''); ?></h5>
        </div>
    <?php endif; ?>

    <?php echo e($slot); ?>


</div><?php /**PATH C:\wamp64\www\ring\resources\views/components/pnlx.blade.php ENDPATH**/ ?>