<div class="panel panel-default">
    <?php if(isset($name)): ?>
        <div class="panel-heading">
            <h5 class="panel-title"><i class="icon-shutter text-info"></i> <?php echo e($name ?? ''); ?></h5>
            <?php if(isset($body)): ?>
                <div class="heading-elements">
                    <button id="headerBtn" type="button" class="btn btn-primary heading-btn btn-labeled btn-labeled-left" data-toggle="modal" data-target="#myModal"><b><i class="icon-add-to-list"></i></b> <?php echo e($body); ?></button>
                </div>
            <?php endif; ?>

        </div>

    <?php endif; ?>

    <div class="panel-body"></div>

    <div class="table-responsive" style="overflow-x: inherit;">
        <?php echo e($slot); ?>

    </div>

</div>
<?php /**PATH C:\wamp64\www\ring\resources\views\components\page.blade.php ENDPATH**/ ?>