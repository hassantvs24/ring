

<?php $__env->startSection('title'); ?>
    Sales Invoice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.print','data' => ['header' => 'Sales Invoice Report']]); ?>
<?php $component->withName('print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => 'Sales Invoice Report']); ?>
         <?php $__env->slot('sub'); ?> 
        <?php if(isset($request['due'])): ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report']); ?>Due Invoice Report <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Date Range']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Date Range']); ?><?php echo e($request['date_range']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php
                $tablex = $table->where('BalanceDue', '>', 0)->all();
            ?>
        <?php else: ?>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Date Range']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Date Range']); ?><?php echo e($request['date_range']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php
                $tablex = $table;
            ?>
        <?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('subr'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report Date']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report Date']); ?><?php echo e(date('d/m/Y')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

        <table class="table table-condensed table-bordered table-striped">
            <thead>
            <tr>
                <th>Date</th>
                <th>S/N</th>
                <th>Customer</th>
                <th>Contact</th>
                <th>Agent</th>
                <th>Amount</th>
                <th>Paid</th>
                <th>Due</th>
                <th>Due Adj.</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $total = 0;
                $total_inv_paid = 0;
                $total_inv_due = 0;
                $total_inv_bal_due = 0;
                $i = 0;
            ?>
            <?php $__currentLoopData = $tablex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(pub_date($row->created_at)); ?></td>
                    <td><?php echo e($row->code); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->contact); ?></td>
                    <td><?php echo e($row->agent['name'] ?? ''); ?></td>
                    <td><?php echo e(money_c($row->invoice_sub_total())); ?></td>
                    <td><?php echo e(money_c($row->invoice_paid())); ?></td>
                    <td><?php echo e(money_c($row->invoice_due())); ?></td>
                    <td><?php echo e(money_c($row->balance_due())); ?></td>
                </tr>
                <?php
                    $total += $row->invoice_sub_total();
                    $total_inv_paid += $row->invoice_paid();
                    $total_inv_due += $row->invoice_due();
                    $total_inv_bal_due += $row->balance_due();
                    $i++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <th class="text-right" colspan="5">Total(<?php echo e($i); ?>)</th>
                <th><?php echo e(money_c($total)); ?></th>
                <th><?php echo e(money_c($total_inv_paid)); ?></th>
                <th><?php echo e(money_c($total_inv_due)); ?></th>
                <th><?php echo e(money_c($total_inv_bal_due)); ?></th>
            </tr>
            </tfoot>
        </table>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/reports/print/sales.blade.php ENDPATH**/ ?>