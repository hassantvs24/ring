

<?php $__env->startSection('title'); ?>
    Stock Transaction
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Page::class, ['name' => 'Stock Transaction']); ?>
<?php $component->withName('page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">Date</th>
                <th class="p-th">SKU</th>
                <th class="p-th">Name</th>
                <th class="p-th">Transaction Point</th>
                <th class="p-th">IN</th>
                <th class="p-th">OUT</th>
                <th class="p-th">Unit</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e(pub_date($row->created_at)); ?></td>
                    <td class="p-td"><?php echo e($row->sku); ?></td>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->transaction_point); ?></td>
                    <td class="p-td"><?php echo e($row->transaction_type == 'IN' ? $row->quantity : 0); ?></td>
                    <td class="p-td"><?php echo e($row->transaction_type == 'OUT' ? $row->quantity : 0); ?></td>
                    <td class="p-td"><?php echo e($row->unit); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89)): ?>
<?php $component = $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89; ?>
<?php unset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {

            $('.datatable-basic').DataTable({
                columnDefs: [
                   // { orderable: false, "targets": [3] }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\stock\stock_transaction.blade.php ENDPATH**/ ?>