<div id="signature">
    <?php if(isset($left)): ?>
    <div id="authorize_signature"><?php echo e($left ?? ''); ?></div><!--Authorize Signature-->
    <?php endif; ?>
    <?php if(isset($right)): ?>
        <div id="customer_signature"><?php echo e($right ?? ''); ?></div><!--Customer Signature-->
    <?php endif; ?>
</div><?php /**PATH C:\wamp64\www\ring\resources\views/components/signature.blade.php ENDPATH**/ ?>