


<?php $__env->startSection('title'); ?>
    Supplier
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Site::class, ['name' => 'Supplier List']); ?>
<?php $component->withName('site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('header'); ?> 
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Create')): ?>
                <button id="headerBtn" type="button" class="btn btn-primary heading-btn btn-labeled btn-labeled-left" data-toggle="modal" data-target="#myModal"><b><i class="icon-add-to-list"></i></b> Add New Supplier</button>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">S/N</th>
                <th class="p-th">Name</th>
                <th class="p-th">Contact</th>
                <th class="p-th">Email</th>
                <th class="p-th">Address</th>
                <th class="p-th">Phone</th>
                <th class="p-th">Contact2</th>
                <th class="p-th">Category</th>
                <th class="p-th">Warehouse</th>
                <th class="p-th">Due</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->code); ?></td>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->contact); ?></td>
                    <td class="p-td"><?php echo e($row->email); ?></td>
                    <td class="p-td"><?php echo e($row->address); ?></td>
                    <td class="p-td"><?php echo e($row->phone); ?></td>
                    <td class="p-td"><?php echo e($row->alternate_contact); ?></td>
                    <td class="p-td"><?php echo e($row->supplierCategory['name']); ?></td>
                    <td class="p-td"><?php echo e($row->warehouse['name']); ?></td>
                    <td class="p-td"><?php echo e($row->dueBalance()); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Edit')): ?>
                                <li><a href="#<?php echo e(route('supplier.update', ['list' => $row->id])); ?>"
                                   data-category="<?php echo e($row->supplier_categories_id); ?>"
                                   data-warehouses="<?php echo e($row->warehouses_id); ?>"
                                   data-name="<?php echo e($row->name); ?>"
                                   data-code="<?php echo e($row->code); ?>"
                                   data-contact="<?php echo e($row->contact); ?>"
                                   data-email="<?php echo e($row->email); ?>"
                                   data-address="<?php echo e($row->address); ?>"
                                   data-phone="<?php echo e($row->phone); ?>"
                                   data-contacttwo="<?php echo e($row->alternate_contact); ?>"
                                   data-description="<?php echo e($row->description); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Transaction')): ?>
                                <li><a href="<?php echo e(route('supplier.show', ['list' => $row->id])); ?>"><i class="icon-shuffle text-primary"></i> Payment Transaction</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Payment')): ?>
                            <?php if($row->dueBalance() != 0): ?>
                                <li><a href="<?php echo e(route('supplier.payment', ['id' => $row->id])); ?>" class="payment" data-balance="<?php echo e($row->dueBalance()); ?>" data-toggle="modal" data-target="#payModal"><i class="icon-wallet text-purple"></i> Due Payment</a></li>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Supplier Delete')): ?>
                                <li><a href="<?php echo e(route('supplier.destroy', ['list' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                            <?php endif; ?>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266)): ?>
<?php $component = $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266; ?>
<?php unset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        var balance = 0;

        $(function () {

            $('.warehouse').val("<?php echo e(auth()->user()->warehouses_id); ?>").select2();
            $('.accounts').val("<?php echo e(auth()->user()->account_books_id); ?>").select2();

            $('.category, .payment_method').select2();

            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href').substr(1);
                var name = $(this).data('name');
                var code = $(this).data('code');
                var contact = $(this).data('contact');
                var email = $(this).data('email');
                var address = $(this).data('address');
                var phone = $(this).data('phone');
                var alternate_contact = $(this).data('contacttwo');
                var description = $(this).data('description');
                var supplier_categories_id = $(this).data('category');
                var warehouses_id = $(this).data('warehouses');


                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=warehouses_id]').val(warehouses_id).select2();
                $('#ediModal [name=supplier_categories_id]').val(supplier_categories_id).select2();
                $('#ediModal [name=code]').val(code);
                $('#ediModal [name=contact]').val(contact);
                $('#ediModal [name=email]').val(email);
                $('#ediModal [name=address]').val(address);
                $('#ediModal [name=phone]').val(phone);
                $('#ediModal [name=description]').val(description);
                $('#ediModal [name=alternate_contact]').val(alternate_contact);
            });

            $('.payment').click(function (e) {
                e.preventDefault();

                balance = $(this).data('balance');

                $('#payModal [name=amount]').val(0);

                $('.cheque_number').hide();
                $('.bank_account_no').hide();
                $('.transaction_no').hide();

                var url = $(this).attr('href');
                $('#payModal form').attr('action', url);

            });


            $('.payment_method').change(function () {
                var methods = $(this).val();
                switch(methods) {
                    case "Cheque":
                        $('.cheque_number').show();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        break;
                    case "Bank Transfer":
                        $('.cheque_number').hide();
                        $('.bank_account_no').show();
                        $('.transaction_no').hide();
                        break;
                    case "Other":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').show();
                        break;
                    case "Customer Account":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        break;
                    default:
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                }
            });


            $('.date_pic').daterangepicker({
                singleDatePicker: true,
                locale: {
                    format: 'DD/MM/YYYY'
                }
            });

            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [9] }
                ]
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('supplier.box.supplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/supplier/supplier.blade.php ENDPATH**/ ?>