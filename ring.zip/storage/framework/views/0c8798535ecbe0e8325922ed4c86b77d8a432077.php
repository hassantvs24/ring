<div class="panel panel-default">
    <?php if(isset($name)): ?>
        <div class="panel-heading">
            <h5 class="panel-title"><i class="icon-shutter text-info"></i> <?php echo e($name ?? ''); ?></h5>
        </div>
    <?php endif; ?>

    <div class="panel-body">
        <?php echo e($slot); ?>

    </div>

</div>
<?php /**PATH C:\wamp64\www\ring\resources\views\components\panel.blade.php ENDPATH**/ ?>