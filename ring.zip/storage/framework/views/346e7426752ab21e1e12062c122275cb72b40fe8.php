

<?php $__env->startSection('title'); ?>
    Stock Transaction Reports
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.print','data' => ['header' => 'Stock Transaction Reports']]); ?>
<?php $component->withName('print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => 'Stock Transaction Reports']); ?>
         <?php $__env->slot('sub'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Date Range']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Date Range']); ?><?php echo e($request['date_range']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('subr'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report Date']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report Date']); ?><?php echo e(date('d/m/Y')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

        <table class="table table-condensed table-bordered table-striped">
            <thead>
            <tr>
                <th>Date</th>
                <th>SKU</th>
                <th>Name</th>
                <th>Ref</th>
                <th>Unit</th>
                <th>IN</th>
                <th>OUT</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $total_in = 0;
                $total_out = 0;
            ?>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(pub_date($row->created_at)); ?></td>
                    <td><?php echo e($row->sku); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->transaction_point); ?></td>
                    <td><?php echo e($row->unit); ?></td>
                    <td><?php echo e($row->in()); ?></td>
                    <td><?php echo e($row->out()); ?></td>
                </tr>
                <?php
                    $total_in += $row->in();
                    $total_out += $row->out();
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <th class="text-right" colspan="5">Total</th>
                <th><?php echo e($total_in); ?></th>
                <th><?php echo e($total_out); ?></th>
            </tr>
            </tfoot>
        </table>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/reports/print/product-transaction.blade.php ENDPATH**/ ?>