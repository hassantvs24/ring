

<?php $__env->startSection('content'); ?>

    <!-- Advanced login -->
    <form  method="POST" action="<?php echo e(route('key.active')); ?>">
        <?php echo csrf_field(); ?>
        <div class="panel panel-body login-form">
            <div class="text-center">
                <div class="icon-object border-slate-300 text-slate-300"><i class="icon-key"></i></div>
                <h5 class="content-group">Activate Your Software</h5>
            </div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('activation_code') ? ' has-error' : ''); ?>">
                <input type="text" class="form-control" placeholder="Activation Code" name="activation_code" required>
                <div class="form-control-feedback">
                    <i class="icon-key text-muted"></i>
                </div>
                <?php if($errors->has('activation_code')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('activation_code')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <!--<p><?php echo e(Auth::user()->business['software_key']); ?></p>-->

            <div class="form-group">
                <button type="submit" class="btn bg-blue btn-block"><i class="icon-unlocked position-right"></i> Activate</button>
            </div>
            <p class="text-center" title="Go to dashboard"><a href="<?php echo e(route('index')); ?>"><i class="icon-home4"></i></a></p>
        </div>
    </form>
    <!-- /advanced login -->
    <p class="text-center text-warning text-size-large text-semibold">Remaining Day: <?php echo e($remain); ?></p>
    <p class="text-center text-grey-300 text-size-mini"><?php echo e(Auth::user()->business['software_key']); ?></p>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/auth/key.blade.php ENDPATH**/ ?>