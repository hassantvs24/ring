

<?php $__env->startSection('title'); ?>
    Party Ledger Reports
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.print','data' => ['header' => 'Customer Ledger Report']]); ?>
<?php $component->withName('print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => 'Customer Ledger Report']); ?>
         <?php $__env->slot('sub'); ?> 
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Date Range']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Date Range']); ?><?php echo e($request['date_range']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('subr'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report Date']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report Date']); ?><?php echo e(date('d/m/Y')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

        <table class="table table-condensed table-bordered table-striped">
            <thead>
            <tr>
                <th>Party Name</th>
                <th>Address</th>
                <!--<th>Qty</th>
                <th>Delivery Amount</th>-->
                <th>Collection</th>
                <th>Opening Balance</th>
                <th>Closing Balance</th>
                <th>Last Collection</th>
                <th>Cr. Limit</th>
                <th>Usable Balance</th>
                <th>Target</th>
                <!--<th>Agent</th>-->
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php

                    $op_collect_in = $row->transactions()
                     ->whereDate('created_at', '<', $st)
                     ->where('transaction_type', 'IN')
                     ->where('status', 'Active')
                     ->sum('amount');

                     $end_collect_in = $row->transactions()
                     ->whereDate('created_at', '<=', $end)
                     ->where('transaction_type', 'IN')
                     ->where('status', 'Active')
                     ->sum('amount');

                     $op_collect_out = $row->transactions()
                     ->whereDate('created_at', '<', $st)
                     ->where('transaction_type', 'OUT')
                     ->where('status', 'Active')
                     ->sum('amount');

                     $end_collect_out = $row->transactions()
                     ->whereDate('created_at', '<=', $end)
                     ->where('transaction_type', 'OUT')
                     ->where('status', 'Active')
                     ->sum('amount');

                     $op_collect = $op_collect_in - $op_collect_out;
                     $end_collect = $end_collect_in - $end_collect_out;

                      $op_invoices = $row->sellInvoices()
                     ->whereDate('created_at', '<', $st)
                     ->where('status', 'Final')
                     ->get();
                     $op_invoices_amount = $op_invoices->sum('SubTotal');

                     $end_invoices = $row->sellInvoices()
                     ->whereDate('created_at', '<=', $end)
                     ->where('status', 'Final')
                     ->get();
                     $end_invoices_amount = $end_invoices->sum('SubTotal');

                     $op_balance = $op_collect - $op_invoices_amount;

                     $end_balance = $end_collect - $end_invoices_amount;

                     $last_collect = $row->transactions()
                     ->whereBetween('created_at', $range)
                     ->where('transaction_type', 'IN')
                     ->where('status', 'Active')
                     ->orderBy('created_at', 'desc')
                     ->first();

                     $collect = $row->transactions()
                     ->whereBetween('created_at', $range)
                     ->where('transaction_type', 'IN')
                     ->where('status', 'Active')
                     ->sum('amount');

                     $invoices = $row->sellInvoices()
                     ->whereBetween('created_at', $range)
                     ->where('status', 'Final')
                     ->get();

                     /*$qty = 0;
                     $amount = 0;
                     foreach ($invoices as $rows){
                        $products = $rows->main_product();
                        $qty += $products['qty'];
                        $amount += $products['amount'];
                     }*/

                ?>
                <tr>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->address); ?></td>
                    <!--<td></td>
                    <td></td>-->
                    <td><?php echo e(money_c($collect)); ?></td>
                    <td><?php echo e(money_c($op_balance)); ?></td>
                    <td><?php echo e(money_c($end_balance)); ?></td>
                    <?php if(isset($last_collect->created_at)): ?>
                        <td><?php echo e(pub_date($last_collect->created_at)); ?></td>
                    <?php else: ?>
                        <td>--</td>
                    <?php endif; ?>
                    <td><?php echo e(money_c($row->credit_limit)); ?></td>
                    <td><?php echo e(money_c($row->credit_limit + $end_balance)); ?></td>
                    <td><?php echo e($row->sells_target); ?></td>
                    <!--<td></td>-->

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/reports/print/all_customer_ledger.blade.php ENDPATH**/ ?>