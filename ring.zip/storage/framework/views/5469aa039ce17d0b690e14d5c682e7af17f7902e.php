


<?php $__env->startSection('title'); ?>
    Stock List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Page::class, ['name' => 'Stock List','body' => 'Add Products']); ?>
<?php $component->withName('page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">S/N</th>
                <th class="p-th">Name</th>
                <th class="p-th">Type</th>
                <th class="p-th">Category</th>
                <th class="p-th">Brand</th>
                <th class="p-th">Company</th>
                <th title="Sales Price" class="p-th">S.Price</th>
                <th title="Purchase Price" class="p-th">P.Price</th>
                <th title="Alert Quantity" class="p-th">A.Qty</th>
                <th class="p-th">Stock</th>
                <th class="p-th">Unit</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->sku); ?></td>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->product_type); ?></td>
                    <td class="p-td"><?php echo e($row->productCategory['name']); ?></td>
                    <td class="p-td"><?php echo e($row->brand['name']); ?></td>
                    <td class="p-td"><?php echo e($row->company['name']); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->sell_price)); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->purchase_price)); ?></td>
                    <td class="p-td"><?php echo e($row->alert_quantity); ?></td>
                    <td class="p-td"><?php echo e($row->currentStock()); ?></td>
                    <td class="p-td"><?php echo e($row->unit['name']); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <li><a href="<?php echo e(route('stock.transaction', ['id' => $row->id])); ?>"><i class="icon-shuffle text-primary"></i> Stock Transaction</a></li>
                            <li><a href="<?php echo e(route('products.update', ['product' => $row->id])); ?>"
                                   data-name="<?php echo e($row->name); ?>"
                                   data-sku="<?php echo e($row->sku); ?>"
                                   data-ptype="<?php echo e($row->product_type); ?>"
                                   data-category="<?php echo e($row->product_categories_id); ?>"
                                   data-brand="<?php echo e($row->brands_id); ?>"
                                   data-companies="<?php echo e($row->companies_id); ?>"
                                   data-sell="<?php echo e($row->sell_price); ?>"
                                   data-purchase="<?php echo e($row->purchase_price); ?>"
                                   data-stock="<?php echo e($row->stock); ?>"
                                   data-units="<?php echo e($row->units_id); ?>"
                                   data-aqty="<?php echo e($row->alert_quantity); ?>"
                                   data-description="<?php echo e($row->description); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                            <li><a href="<?php echo e(route('products.destroy', ['product' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89)): ?>
<?php $component = $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89; ?>
<?php unset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var name = $(this).data('name');
                var sku = $(this).data('sku');
                var product_type = $(this).data('ptype');
                var product_categories_id = $(this).data('category');
                var brands_id = $(this).data('brand');
                var companies_id = $(this).data('companies');
                var sell_price = $(this).data('sell');
                var purchase_price = $(this).data('purchase');
                var stock = $(this).data('stock');
                var units_id = $(this).data('units');
                var alert_quantity = $(this).data('aqty');
                var description = $(this).data('description');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=sku]').val(sku);
                $('#ediModal [name=product_type]').val(product_type).select2();
                $('#ediModal [name=product_categories_id]').val(product_categories_id).select2();
                $('#ediModal [name=brands_id]').val(brands_id).select2();
                $('#ediModal [name=companies_id]').val(companies_id).select2();
                $('#ediModal [name=sell_price]').val(sell_price);
                $('#ediModal [name=purchase_price]').val(purchase_price);
                $('#ediModal [name=stock]').val(stock);
                $('#ediModal [name=units_id]').val(units_id).select2();
                $('#ediModal [name=alert_quantity]').val(alert_quantity);
                $('#ediModal [name=description]').val(description);

            });

            $('.product_type, .category, .brands, .companies, .units').select2();


            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [11] }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('stock.box.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\stock\products.blade.php ENDPATH**/ ?>