<?php $__env->startSection('content'); ?>

    <!-- Advanced login -->
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="panel panel-body login-form">
            <div class="text-center">
                <div class="icon-object border-success text-success"><i class="icon-plus3"></i></div>
                <h5 class="content-group">Create account <small class="display-block">All fields are required</small></h5>
            </div>

            <div class="content-divider text-muted form-group"><span>Your credentials</span></div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <input type="text" class="form-control" placeholder="User Name" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                <div class="form-control-feedback">
                    <i class="icon-user-check text-muted"></i>
                </div>
                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input type="email" class="form-control" placeholder="Your email" name="email" value="<?php echo e(old('email')); ?>" required>
                <div class="form-control-feedback">
                    <i class="icon-mention text-muted"></i>
                </div>
                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group has-feedback has-feedback-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <input type="password" class="form-control" placeholder="Create password" name="password" required>
                <div class="form-control-feedback">
                    <i class="icon-user-lock text-muted"></i>
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group has-feedback has-feedback-left">
                <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation" required>
                <div class="form-control-feedback">
                    <i class="icon-user-lock text-muted"></i>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn bg-teal btn-block btn-lg">Register <i class="icon-circle-right2 position-right"></i></button>
            </div>

            <div class="content-divider text-muted form-group"><span>Allready have an account?</span></div>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-default btn-block content-group">Sign in</a>

        </div>
    </form>
    <!-- /advanced login -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\auth\register.blade.php ENDPATH**/ ?>