


<?php $__env->startSection('title'); ?>
    Balance Sheet
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Panel::class, ['name' => 'Balance Sheet']); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-bordered table-condensed table-hover">
            <thead>
            <tr>
                <th>Trial Balance</th>
                <th>Credit</th>
                <th>Debit</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Supplier Due:</th>
                    <td></td>
                    <td><?php echo e(money_c($supplier_due)); ?></td>
                </tr>
                <tr>
                    <th>Customer Due:</th>
                    <td><?php echo e(money_c($customer_due)); ?></td>
                    <td></td>
                </tr>
                <tr>
                    <th>Account Balances:</th>
                    <td></td>
                    <td></td>
                </tr>
                <?php
                    $ac_balance = 0;
                ?>
                <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="pl-20"><?php echo e($row->name); ?>:</span></td>
                        <td><?php echo e(money_c($row->acBalance())); ?></td>
                        <td></td>
                    </tr>
                    <?php
                        $ac_balance += $row->acBalance();
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot>
            <tr>
                <th>Total</th>
                <td><?php echo e(money_c($credit + $ac_balance)); ?></td>
                <td><?php echo e(money_c($debit)); ?></td>
            </tr>
            </tfoot>
        </table>

     <?php if (isset($__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52)): ?>
<?php $component = $__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52; ?>
<?php unset($__componentOriginal2cfb2727414d28f1d2ba20b22e14c0766904fa52); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('box.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/accounts/trial_balance.blade.php ENDPATH**/ ?>