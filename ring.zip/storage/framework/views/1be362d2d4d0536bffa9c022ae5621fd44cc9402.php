<?php if(isset($header)): ?>
<div class="row mb-15">
    <div class="col-sm-12"><h5 class="text-center"><strong><?php echo e($header); ?></strong></h5></div>
</div>
<?php endif; ?>

<?php if(isset($sub) || isset($subr)): ?>
    <div class="row mb-15">
        <div class="col-sm-6"><?php echo e($sub ?? ''); ?></div>
        <div class="col-sm-6 text-right"><?php echo e($subr ?? ''); ?></div>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-sm-12">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\wamp64\www\ring\resources\views/components/print.blade.php ENDPATH**/ ?>