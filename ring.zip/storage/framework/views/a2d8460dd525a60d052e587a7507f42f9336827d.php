

<?php $__env->startSection('title'); ?>
    Purchase Invoice Item Ledger
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.print','data' => ['header' => 'Purchase Invoice Item Ledger Reports']]); ?>
<?php $component->withName('print'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['header' => 'Purchase Invoice Item Ledger Reports']); ?>
         <?php $__env->slot('sub'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Date Range']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Date Range']); ?><?php echo e($request['date_range']); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('subr'); ?>  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bp','data' => ['b' => 'Report Date']]); ?>
<?php $component->withName('bp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['b' => 'Report Date']); ?><?php echo e(date('d/m/Y')); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  <?php $__env->endSlot(); ?>

        <table class="table table-condensed table-bordered table-striped">
            <thead>
            <tr>
                <th>Date</th>
                <th>SKU</th>
                <th>Product</th>
                <th>Invoice No</th>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Rate</th>
                <th>Total</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $total_sales = 0;
            ?>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(pub_date($row->created_at)); ?></td>
                    <td><?php echo e($row->sku); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->purchaseInvoice['code']); ?></td>
                    <td><?php echo e($row->quantity); ?></td>
                    <td><?php echo e($row->unit); ?></td>
                    <td><?php echo e(money_c($row->amount)); ?></td>
                    <td><?php echo e(money_c($row->amount * $row->quantity)); ?></td>
                </tr>
                <?php
                    $total_sales += ($row->amount * $row->quantity);
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <th class="text-right" colspan="7">Total Sales</th>
                <th><?php echo e(money_c($total_sales)); ?></th>
            </tr>
            </tfoot>
        </table>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views/reports/print/purchase_item.blade.php ENDPATH**/ ?>