<ul class="icons-list">
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="icon-menu9"></i>
        </a>

        <ul class="dropdown-menu dropdown-menu-right" style="z-index: 999999;">
            <?php echo e($slot); ?>

        </ul>
    </li>
</ul><?php /**PATH C:\wamp64\www\ring\resources\views/components/actions.blade.php ENDPATH**/ ?>