<div id="footer">
    <p id="footaddress"><?php echo e($slot); ?></p>
    <p id="powered">&copy; Powered by <i>Infinity Flame Soft &copy;</i></p>
</div><?php /**PATH C:\wamp64\www\ring\resources\views\components\print-footer.blade.php ENDPATH**/ ?>