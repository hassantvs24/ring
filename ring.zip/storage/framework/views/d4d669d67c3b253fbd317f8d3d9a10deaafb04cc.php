


<?php $__env->startSection('title'); ?>
    User Roles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


     <?php if (isset($component)) { $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Page::class, ['name' => 'User Roles','body' => 'New Roles']); ?>
<?php $component->withName('page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">Role Name</th>
                <th class="p-th">Number Of Permission</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e($row->name); ?></td>
                    <td class="p-td"><?php echo e($row->getAllPermissions()->count()); ?></td>
                    <td class="text-right p-td">
                        <?php
                            $data = [];
                            $old_permission = $row->getAllPermissions();
                            foreach ($old_permission as $permit){
                                $data[] = $permit->id;
                            }
                        ?>
                        <?php if($row->name != 'Super Admin'): ?>
                             <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                    <li><a href="<?php echo e(route('role.permission', ['role' => $row->id])); ?>" class="permissionEdit" data-permission="<?php echo e(json_encode($data)); ?>" data-toggle="modal" data-target="#permissionModal"><i class="icon-magic-wand text-warning"></i> Add Permission</a></li>
                                    <li><a href="<?php echo e(route('roles.update', ['role' => $row->id])); ?>"
                                           data-name="<?php echo e($row->name); ?>"
                                           class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>
                                    <li><a href="<?php echo e(route('roles.destroy', ['role' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                             <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

     <?php if (isset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89)): ?>
<?php $component = $__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89; ?>
<?php unset($__componentOriginal66c3b89c299603c3a684c7b496e4125b0e9b2c89); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function () {
            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var name = $(this).data('name');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
            });

            $('.permissionEdit').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var permission = $(this).data('permission');
                $('#permissionModal form').attr('action', url);
                $('#permissionModal input:checkbox').prop('checked',false);

                $.each(permission, function( index, value ) {
                   // alert( index + ": " + value );
                    $('#permissionModal .val_'+value+':checkbox').prop('checked',true);
                });

            });

            $('.selectAll').click(function () {
                $('#permissionModal input:checkbox').prop('checked',true);
            });

            $('.unSelectAll').click(function () {
                $('#permissionModal input:checkbox').prop('checked',false);
            });


            $('.datatable-basic').DataTable({
                columnDefs: [
                    { orderable: false, "targets": [2] }
                ]
            });
        });



    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.box.roles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\users\roles.blade.php ENDPATH**/ ?>