

<?php $__env->startSection('title'); ?>
    <?php echo e($customer->name); ?> - Payment Transaction
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

     <?php if (isset($component)) { $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Site::class, ['name' => ''.e($customer->name).'']); ?>
<?php $component->withName('site'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

         <?php $__env->slot('header'); ?> 
            <a href="<?php echo e(route('customer.index')); ?>" class="btn btn-danger heading-btn btn-labeled btn-labeled-left"><b><i class="icon-arrow-left5"></i></b> Back to customer list</a>
            <button id="headerBtn" type="button" class="btn btn-primary heading-btn btn-labeled btn-labeled-left" data-toggle="modal" data-target="#myModal"><b><i class="icon-add-to-list"></i></b> Make Payment</button>
         <?php $__env->endSlot(); ?>

        <table class="table table-striped table-condensed table-hover datatable-basic">
            <thead>
            <tr>
                <th class="p-th">Date</th>
                <th class="p-th">Account Book</th>
                <th class="p-th">Payment Method</th>
                <th class="p-th">Payment No</th>
                <th class="p-th">Description</th>
                <th class="p-th">Payment Section</th>
                <th class="p-th">IN</th>
                <th class="p-th">OUT</th>
                <th class="text-right"><i class="icon-more"></i></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-td"><?php echo e(pub_date($row->created_at)); ?></td>
                    <td class="p-td"><?php echo e($row->accountBook['name']); ?></td>
                    <td class="p-td"><?php echo e($row->payment_method); ?></td>

                    <?php switch($row->payment_method):
                        case ('Cheque'): ?>
                        <td class="p-td" title="Cheque Number"><?php echo e($row->cheque_number); ?></td>
                        <?php break; ?>

                        <?php case ('Bank Transfer'): ?>
                        <td class="p-td" title="Account Number"><?php echo e($row->bank_account_no); ?></td>
                        <?php break; ?>

                        <?php case ('Other'): ?>
                        <td class="p-td" title="Other Transaction Number"><?php echo e($row->transaction_no); ?></td>
                        <?php break; ?>

                        <?php default: ?>
                        <td class="p-td"></td>
                    <?php endswitch; ?>

                    <td class="p-td" title="Bank name or Other note"><?php echo e($row->description); ?></td>
                    <td class="p-td"><?php echo e($row->transaction_point); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->transaction_type == 'IN' ? $row->amount : 0)); ?></td>
                    <td class="p-td"><?php echo e(money_c($row->transaction_type == 'OUT' ? $row->amount : 0)); ?></td>
                    <td class="text-right p-td">
                         <?php if (isset($component)) { $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Actions::class, []); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <!--<li><a href="<?php echo e(route('customer.edit-payment', ['id' => $row->id, 'customer' => $customer->id])); ?>"
                                   data-acbook="<?php echo e($row->account_books_id); ?>"
                                   data-pmethod="<?php echo e($row->payment_method); ?>"
                                   data-ptype="<?php echo e($row->payment_type); ?>"
                                   data-cheque="<?php echo e($row->cheque_number); ?>"
                                   data-bac="<?php echo e($row->bank_account_no); ?>"
                                   data-trno="<?php echo e($row->transaction_no); ?>"
                                   data-description="<?php echo e($row->description); ?>"
                                   data-amount="<?php echo e($row->amount); ?>"
                                   data-warehouses="<?php echo e($row->warehouses_id); ?>"
                                   class="ediItem" data-toggle="modal" data-target="#ediModal"><i class="icon-pencil6 text-success"></i> Edit</a></li>-->
                            <li><a href="<?php echo e(route('customer.del-payment', ['id' => $row->id])); ?>" class="delItem"><i class="icon-bin text-danger"></i> Delete</a></li>
                         <?php if (isset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869)): ?>
<?php $component = $__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869; ?>
<?php unset($__componentOriginalac6efd7fcc4d4af12e7c49eccb7d7843158c0869); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="text-danger">
                <th class="text-right p-td" colspan="3">Total Sales</th>
                <th class="p-td"><?php echo e(money_c($customer->totalSales())); ?></th>
                <th class="text-right p-td">Total Payment</th>
                <th class="p-td"><?php echo e(money_c($customer->totalPayment())); ?></th>
                <th class="text-right p-td">Total Balance</th>
                <th class="p-td"><?php echo e(money_c($customer->dueBalance())); ?></th>
                <th class="p-td"></th>
            </tr>
            </tfoot>
        </table>

     <?php if (isset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266)): ?>
<?php $component = $__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266; ?>
<?php unset($__componentOriginal829a229d00ad4f9951f1189b47f2b82eec3c9266); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        var balance = 0;

        $(function () {
            $('.warehouse').val("<?php echo e(auth()->user()->warehouses_id); ?>").select2();
            $('.accounts').val("<?php echo e(auth()->user()->account_books_id); ?>").select2();

            $('.payment_method').select2();

            $('.ediItem').click(function (e) {
                e.preventDefault();
                var url = $(this).attr('href');
                var warehouses_id = $(this).data('warehouses');
                var account_books_id = $(this).data('acbook');
                var payment_method = $(this).data('pmethod');
                var payment_type = $(this).data('ptype');
                var cheque_number = $(this).data('cheque');
                var transaction_no = $(this).data('trno');
                var bank_account_no = $(this).data('bac');
                var description = $(this).data('description');
                var amount = $(this).data('amount');


                $('#ediModal form').attr('action', url);
                $('#ediModal [name=warehouses_id]').val(warehouses_id).select2();
                $('#ediModal [name=account_books_id]').val(account_books_id).select2();
                $('#ediModal [name=payment_method]').val(payment_method).select2();
                $('#ediModal [name=payment_type]').val(payment_type).select2();
                $('#ediModal [name=cheque_number]').val(cheque_number);
                $('#ediModal [name=transaction_no]').val(transaction_no);
                $('#ediModal [name=bank_account_no]').val(bank_account_no);
                $('#ediModal [name=description]').val(description);
                $('#ediModal [name=amount]').val(amount);


                $('#ediModal [name=zones_id]').val(zones_id).select2();
                $('#ediModal [name=warehouses_id]').val(warehouses_id).select2();
                $('#ediModal [name=customer_categories_id]').val(customer_categories_id).select2();

            });

            $('#headerBtn').click(function () {

                $('#myModal [name=amount]').val(0);

                $('.cheque_number').hide();
                $('.bank_account_no').hide();
                $('.transaction_no').hide();


                disible_submit();
            });


            $('.payment_method').change(function () {
                var methods = $(this).val();
                switch(methods) {
                    case "Cheque":
                        $('.cheque_number').show();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                        break;
                    case "Bank Transfer":
                        $('.cheque_number').hide();
                        $('.bank_account_no').show();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                        break;
                    case "Other":
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').show();
                        $('.customer_balance').hide();
                        break;
                    case "Customer Account":
                        $('.customer_balance').html('Account Current Balance: '+parseFloat(balance).toFixed(2));
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').show();
                        break;
                    default:
                        $('.cheque_number').hide();
                        $('.bank_account_no').hide();
                        $('.transaction_no').hide();
                        $('.customer_balance').hide();
                }

                disible_submit();

            });

            $('#myModal [name=amount]').on('keyup keydown change', function () {
                disible_submit();
            });

            $('.date_pic').daterangepicker({
                singleDatePicker: true,
                locale: {
                    format: 'DD/MM/YYYY'
                }
            });

            $('.datatable-basic').DataTable({
                columnDefs: [
                     { orderable: false, "targets": [8] }
                ]
            });
        });

        function disible_submit() {
            var amount = $('#myModal [name=amount]').val();
            var payment_method = $('.payment_method').val();

            if(amount <= 0 || amount > balance && payment_method == 'Customer Account'){
                $('#myModal [type=submit]').prop('disabled', true);
            }else{
                $('#myModal [type=submit]').prop('disabled', false);
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.box.transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ring\resources\views\customer\transaction.blade.php ENDPATH**/ ?>