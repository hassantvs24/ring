<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
         //$this->call(BusinessSeeder::class);
         //$this->call(UserSeeder::class);
         //$this->call(UserRolesSeeder::class);
         //$this->call(UserRoleUpdateSeeder::class);
         //$this->call(DivisionSeeder::class);
         //$this->call(ZillaSeeder::class);
         //$this->call(UpaZillaSeeder::class);
         //$this->call(UnionSeeder::class);
        //$this->call(PermissionTableSeeder::class);
    }
}
